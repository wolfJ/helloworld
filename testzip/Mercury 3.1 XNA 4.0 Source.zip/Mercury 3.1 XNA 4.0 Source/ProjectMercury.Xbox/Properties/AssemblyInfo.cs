﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Project Mercury Xbox Core")]
[assembly: AssemblyProduct("Mercury Particle Engine")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright © Matt Davey 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components. Xbox 360 assemblies do not support COM.
[assembly: ComVisible(false)]

// If this assembly is the startup assembly, the following Guid is used to
// uniquely identify the title storage container when deploying this assembly
// to the Xbox 360 console.
[assembly: Guid("87b7dd86-6297-4a0e-8587-86022b58bb50")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("3.1.0.0")]