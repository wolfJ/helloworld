﻿namespace ProjectMercury.EffectEditor.Controllers
{
    using Microsoft.Xna.Framework;
    using ProjectMercury.Controllers;

    /// <summary>
    /// Defines a controller which enables the particle effect for editor support.
    /// </summary>
    public sealed class EditorSupportController : Controller
    {
    }
}